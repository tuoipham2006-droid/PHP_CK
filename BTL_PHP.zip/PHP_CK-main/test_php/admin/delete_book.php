
<?php

// ======================================
// 1. KHỞI ĐỘNG VÀ KẾT NỐI
// ======================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once "../includes/data.php";
require_once "../includes/functions.php";

// Chỉ Admin mới được xóa sách
requireAdmin();

// Chỉ chấp nhận POST
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php");
    exit;
}

// ======================================
// 2. KIỂM TRA CSRF TOKEN
// ======================================

$token = $_POST["csrf_token"] ?? "";

if (
    empty($_SESSION["csrf_token"]) ||
    !is_string($token) ||
    !hash_equals($_SESSION["csrf_token"], $token)
) {
    die("Yêu cầu không hợp lệ. Vui lòng tải lại trang.");
}

// ======================================
// 3. KIỂM TRA MÃ SÁCH
// ======================================

$id = (int)($_POST["id"] ?? 0);

if ($id <= 0) {
    header(
        "Location: index.php?message="
        . urlencode("Mã sách không hợp lệ!")
    );
    exit;
}

try {

    // ======================================
    // 4. KIỂM TRA SÁCH CÓ TỪNG ĐƯỢC MUA KHÔNG
    // ======================================

    // Kiểm tra trong bảng chi tiết đơn hàng
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM order_items
        WHERE book_id = ?
    ");

    $stmt->execute([$id]);

    $purchaseCount = (int)$stmt->fetchColumn();

    // Nếu đã có khách hàng mua thì không cho xóa
    if ($purchaseCount > 0) {

        header(
            "Location: index.php?message="
            . urlencode(
                "Không thể xóa sách này vì đã có khách hàng mua. "
                . "Bạn có thể chỉnh sửa hoặc ngừng kinh doanh sách."
            )
        );

        exit;
    }

    // ======================================
    // 5. KIỂM TRA SÁCH TỒN TẠI
    // ======================================

    $stmt = $pdo->prepare("
        SELECT id
        FROM books
        WHERE id = ?
    ");

    $stmt->execute([$id]);

    if (!$stmt->fetch()) {

        header(
            "Location: index.php?message="
            . urlencode("Không tìm thấy sách cần xóa!")
        );

        exit;
    }

    // ======================================
    // 6. XÓA SÁCH NẾU CHƯA TỪNG ĐƯỢC MUA
    // ======================================

    $pdo->beginTransaction();

    // Kiểm tra lại đơn hàng trước khi xóa
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM order_items
        WHERE book_id = ?
    ");

    $stmt->execute([$id]);

    if ((int)$stmt->fetchColumn() > 0) {

        $pdo->rollBack();

        header(
            "Location: index.php?message="
            . urlencode("Sách đã được khách hàng mua, không thể xóa!")
        );

        exit;
    }

    $stmt = $pdo->prepare("
        DELETE FROM books
        WHERE id = ?
    ");

    $stmt->execute([$id]);

    $pdo->commit();

    // Xóa sách khỏi giỏ hàng trong session
    unset($_SESSION["cart"][$id]);

    // Thông báo thành công
    header(
        "Location: index.php?message="
        . urlencode("Đã xóa sách thành công!")
    );

    exit;

} catch (PDOException $ex) {

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log("Delete book error: " . $ex->getMessage());

    header(
        "Location: index.php?message="
        . urlencode("Có lỗi xảy ra khi xóa sách. Vui lòng thử lại!")
    );

    exit;
}

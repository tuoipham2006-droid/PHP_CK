
<?php
session_start();

require_once "../includes/data.php";
require_once "../includes/functions.php";

requireAdmin();

// Lấy danh sách đơn hàng
$stmt = $pdo->query("
    SELECT
        o.id,
        o.receiver,
        o.phone,
        o.address,
        o.total,
        o.payment_method,
        o.payment_status,
        o.status,
        o.created_at,
        o.paid_at
    FROM orders o
    ORDER BY o.id DESC
");

$orders = $stmt->fetchAll();

// Tạo file Excel tương thích CSV
header("Content-Type: text/csv; charset=UTF-8");

header(
    "Content-Disposition: attachment; filename=doanh_thu.csv"
);

// BOM giúp Excel đọc tiếng Việt
echo "\xEF\xBB\xBF";

$output = fopen("php://output", "w");

fputcsv($output, [
    "Ma don hang",
    "Khach hang",
    "So dien thoai",
    "Dia chi",
    "Tong tien",
    "Phuong thuc thanh toan",
    "Trang thai thanh toan",
    "Trang thai don hang",
    "Ngay dat",
    "Ngay thanh toan"
]);

foreach ($orders as $order) {

    fputcsv($output, [
        $order["id"],
        $order["receiver"],
        $order["phone"],
        $order["address"],
        $order["total"],
        $order["payment_method"],
        $order["payment_status"],
        $order["status"],
        $order["created_at"],
        $order["paid_at"]
    ]);
}

fclose($output);
exit;

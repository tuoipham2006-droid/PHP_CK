
<?php

session_start();

require_once "../includes/data.php";
require_once "../includes/functions.php";

/** @var PDO $pdo */

// Kiểm tra quyền quản trị viên
requireAdmin();

// Lấy mã đơn hàng
$id = (int)($_GET["id"] ?? 0);

// Lấy thông tin đơn hàng
$selectedOrder = findOrder($id);

$error = "";

// Xử lý cập nhật đơn hàng
if (
    $selectedOrder &&
    $_SERVER["REQUEST_METHOD"] === "POST"
) {

    $status = $_POST["status"] ?? "";
    $paymentStatus = $_POST["payment_status"] ?? "";

    // Kiểm tra trạng thái đơn hàng
    if (!in_array($status, ORDER_STATUSES, true)) {

        $error = "Trạng thái đơn hàng không hợp lệ.";

    } elseif (
        !in_array(
            $paymentStatus,
            ["Chưa thanh toán", "Đã thanh toán"],
            true
        )
    ) {

        $error = "Trạng thái thanh toán không hợp lệ.";

    } elseif (
        $status === "Đã hủy" &&
        $paymentStatus === "Đã thanh toán"
    ) {

        $error = "Đơn hàng đã hủy không thể xác nhận thanh toán.";

    } else {

        try {

            // Nếu đã thanh toán thì lưu ngày thanh toán
            if ($paymentStatus === "Đã thanh toán") {

                $stmt = $pdo->prepare("
                    UPDATE orders
                    SET status = ?,
                        payment_status = ?,
                        paid_at = COALESCE(paid_at, NOW())
                    WHERE id = ?
                ");

            } else {

                // Nếu chưa thanh toán thì xóa ngày thanh toán
                $stmt = $pdo->prepare("
                    UPDATE orders
                    SET status = ?,
                        payment_status = ?,
                        paid_at = NULL
                    WHERE id = ?
                ");
            }

            $stmt->execute([
                $status,
                $paymentStatus,
                $id
            ]);

            header(
                "Location: order_detail.php?id="
                . $id
                . "&message="
                . urlencode("Cập nhật đơn hàng thành công!")
            );

            exit;

        } catch (PDOException $ex) {

            $error = "Không thể cập nhật đơn hàng. Vui lòng thử lại.";

        }
    }

    // Lấy lại thông tin mới nhất
    $selectedOrder = findOrder($id);
}

include "../includes/header.php";

?>

<div class="page-heading">

    <span class="eyebrow">CHI TIẾT ĐƠN HÀNG</span>

    <h1>Đơn hàng #<?= $id ?></h1>

</div>

<?php if (!$selectedOrder): ?>

    <div class="empty">
        Không tìm thấy đơn hàng.
    </div>

<?php else: ?>

    <div class="cart-list">

        <?php if (!empty($_GET["message"])): ?>

            <div class="success">
                <?= e($_GET["message"]) ?>
            </div>

        <?php endif; ?>

        <?php if ($error !== ""): ?>

            <div class="error">
                <?= e($error) ?>
            </div>

        <?php endif; ?>

        <h3>Thông tin khách hàng</h3>

        <p>
            Họ tên:
            <?= e($selectedOrder["fullname"]) ?>
        </p>

        <p>
            Số điện thoại:
            <?= e($selectedOrder["phone"]) ?>
        </p>

        <p>
            Địa chỉ:
            <?= e($selectedOrder["address"]) ?>
        </p>

        <p>
            Ngày đặt:
            <?= e($selectedOrder["created_at"]) ?>
        </p>

        <h3>Danh sách sản phẩm</h3>

        <?php foreach (getOrderItems($id) as $item): ?>

            <p>
                <?= e($item["title"]) ?>

                - <?= (int)$item["quantity"] ?> cuốn

                - <?= money(
                    $item["price"] * $item["quantity"]
                ) ?>
            </p>

        <?php endforeach; ?>

        <h3>
            Tổng tiền:
            <?= money($selectedOrder["total_price"]) ?>
        </h3>

        <hr>

        <h3>Thông tin thanh toán</h3>

        <p>
            Phương thức:
            <?= e($selectedOrder["payment_method"] ?? "COD") ?>
        </p>

        <p>
            Trạng thái:
            <?= e(
                $selectedOrder["payment_status"]
                ?? "Chưa thanh toán"
            ) ?>
        </p>

        <p>
            Ngày thanh toán:

            <?php if (!empty($selectedOrder["paid_at"])): ?>

                <?= e($selectedOrder["paid_at"]) ?>

            <?php else: ?>

                Chưa thanh toán

            <?php endif; ?>

        </p>

        <hr>

        <h3>Cập nhật đơn hàng</h3>

        <form method="POST">

            <label>Trạng thái đơn hàng</label>

            <select name="status">

                <?php foreach (ORDER_STATUSES as $status): ?>

                    <option
                        value="<?= e($status) ?>"
                        <?= $selectedOrder["status"] === $status
                            ? "selected"
                            : "" ?>
                    >
                        <?= e($status) ?>
                    </option>

                <?php endforeach; ?>

            </select>

            <label>Trạng thái thanh toán</label>

            <select name="payment_status">

                <option
                    value="Chưa thanh toán"
                    <?= $selectedOrder["payment_status"] === "Chưa thanh toán"
                        ? "selected"
                        : "" ?>
                >
                    Chưa thanh toán
                </option>

                <option
                    value="Đã thanh toán"
                    <?= $selectedOrder["payment_status"] === "Đã thanh toán"
                        ? "selected"
                        : "" ?>
                >
                    Đã thanh toán
                </option>

            </select>

            <button type="submit" class="btn">
                Cập nhật đơn hàng
            </button>

        </form>

    </div>

<?php endif; ?>

<?php include "../includes/footer.php"; ?>

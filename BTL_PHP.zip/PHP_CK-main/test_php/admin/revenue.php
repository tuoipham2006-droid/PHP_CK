<?php

session_start();

require_once "../includes/data.php";
require_once "../includes/functions.php";

// Chỉ Admin mới được xem doanh thu
requireAdmin();

// Lấy ngày hiện tại
$today = date("Y-m-d");

// Lấy ngày lọc từ người dùng
$fromDate = isset($_GET["from"]) && is_string($_GET["from"])
    ? $_GET["from"] : "";

$toDate = isset($_GET["to"]) && is_string($_GET["to"])
    ? $_GET["to"] : "";
// Nếu chưa chọn ngày kết thúc thì mặc định là hôm nay
if ($toDate === "") {
    $toDate = $today;
}

// Kiểm tra định dạng ngày
function validRevenueDate(string $date): bool {
    if ($date === "") {
        return true;
    }

    $d = DateTime::createFromFormat("!Y-m-d", $date);

    return $d !== false && $d->format("Y-m-d") === $date;
}

// Khởi tạo thông báo lỗi
$error = "";

// Kiểm tra định dạng ngày
if (!validRevenueDate($fromDate) || !validRevenueDate($toDate)) {
    $error = "Ngày lọc không hợp lệ.";
}

// Không cho phép chọn ngày bắt đầu lớn hơn hôm nay
if ($error === "" && $fromDate !== "" && $fromDate > $today) {
    $error = "Ngày bắt đầu không được lớn hơn ngày hiện tại.";
}

// Không cho phép chọn ngày kết thúc lớn hơn hôm nay
if ($error === "" && $toDate !== "" && $toDate > $today) {
    $error = "Ngày kết thúc không được lớn hơn ngày hiện tại.";
}

// Ngày bắt đầu không được lớn hơn ngày kết thúc
if (
    $error === "" &&
    $fromDate !== "" &&
    $toDate !== "" &&
    $fromDate > $toDate
) {
    $error = "Ngày bắt đầu không được lớn hơn ngày kết thúc.";
}

// Điều kiện lọc theo thời gian thanh toán
$whereDate = "";
$params = [];

if ($fromDate !== "") {
    $whereDate .= " AND paid_at >= ?";
    $params[] = $fromDate . " 00:00:00";
}

if ($toDate !== "") {
    $whereDate .= " AND paid_at < DATE_ADD(?, INTERVAL 1 DAY)";
    $params[] = $toDate;
}

// Khởi tạo số liệu
$totalRevenue = 0;
$paidOrders = 0;
$unpaidOrders = 0;
$cancelledOrders = 0;
$orders = [];
$monthlyRevenue = [];

if ($error === "") {

    // 1. Tổng doanh thu và số đơn đã thanh toán
    $sql = "
        SELECT
            COUNT(*) AS total_orders,
            COALESCE(SUM(total), 0) AS revenue
        FROM orders
        WHERE payment_status = 'Đã thanh toán'
          AND status <> 'Đã hủy'
          AND paid_at IS NOT NULL
          $whereDate
    ";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $result = $stmt->fetch(PDO::FETCH_ASSOC);

    $totalRevenue = (float)$result["revenue"];
    $paidOrders = (int)$result["total_orders"];

    // Điều kiện lọc đơn chưa thanh toán và đơn hủy theo ngày đặt
    $whereCreated = "";
    $createdParams = [];

    if ($fromDate !== "") {
        $whereCreated .= " AND created_at >= ?";
        $createdParams[] = $fromDate . " 00:00:00";
    }

    if ($toDate !== "") {
        $whereCreated .= " AND created_at < DATE_ADD(?, INTERVAL 1 DAY)";
        $createdParams[] = $toDate;
    }

    // 2. Số đơn chưa thanh toán
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM orders
        WHERE payment_status = 'Chưa thanh toán'
          AND status <> 'Đã hủy'
          $whereCreated
    ");

    $stmt->execute($createdParams);
    $unpaidOrders = (int)$stmt->fetchColumn();

    // 3. Số đơn đã hủy
    $stmt = $pdo->prepare("
        SELECT COUNT(*)
        FROM orders
        WHERE status = 'Đã hủy'
        $whereCreated
    ");

    $stmt->execute($createdParams);
    $cancelledOrders = (int)$stmt->fetchColumn();

    // 4. Danh sách đơn đã thanh toán
    $stmt = $pdo->prepare("
        SELECT
            id,
            receiver,
            total,
            payment_method,
            payment_status,
            status,
            paid_at
        FROM orders
        WHERE payment_status = 'Đã thanh toán'
          AND status <> 'Đã hủy'
          AND paid_at IS NOT NULL
          $whereDate
        ORDER BY paid_at DESC
    ");

    $stmt->execute($params);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 5. Thống kê doanh thu theo tháng
    $stmt = $pdo->prepare("
        SELECT
            DATE_FORMAT(paid_at, '%m/%Y') AS month_name,
            SUM(total) AS revenue
        FROM orders
        WHERE payment_status = 'Đã thanh toán'
          AND status <> 'Đã hủy'
          AND paid_at IS NOT NULL
          $whereDate
        GROUP BY YEAR(paid_at), MONTH(paid_at)
        ORDER BY YEAR(paid_at) DESC, MONTH(paid_at) DESC
    ");

    $stmt->execute($params);
    $monthlyRevenue = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

include "../includes/header.php";

?>

<div class="page-heading">

    <span class="eyebrow">QUẢN LÝ BÁN HÀNG</span>

    <h1>Thống kê doanh thu</h1>

    <p>Theo dõi tình hình kinh doanh của Hiệu Sách Nhỏ</p>

</div>

<?php if ($error !== ""): ?>

    <div class="error">
        <?= e($error) ?>
    </div>

<?php else: ?>

    <!-- Các ô thống kê -->
    <div class="admin-stats">

        <div class="stat-card">
            <p>Tổng doanh thu</p>
            <h2><?= money($totalRevenue) ?></h2>
        </div>

        <div class="stat-card">
            <p>Đơn đã thanh toán</p>
            <h2><?= $paidOrders ?></h2>
        </div>

        <div class="stat-card">
            <p>Đơn chưa thanh toán</p>
            <h2><?= $unpaidOrders ?></h2>
        </div>

        <div class="stat-card">
            <p>Đơn đã hủy</p>
            <h2><?= $cancelledOrders ?></h2>
        </div>

    </div>

    <!-- Bộ lọc ngày -->
    <div class="cart-list" style="margin:25px 0">

        <h3>Lọc doanh thu</h3>

        <form method="GET"
              style="display:flex;gap:15px;flex-wrap:wrap;align-items:end">

            <div>
                <label>Từ ngày</label>

                <input type="date"
                       name="from"
                       value="<?= e($fromDate) ?>"
                       max="<?= e($today) ?>">
            </div>

            <div>
                <label>Đến ngày</label>

                <input type="date"
                       name="to"
                       value="<?= e($toDate) ?>"
                       max="<?= e($today) ?>">
            </div>

            <button type="submit" class="btn">
                Lọc dữ liệu
            </button>

            <a href="revenue.php" class="btn">
                Làm mới
            </a>

        </form>

        <p style="color:#777;font-size:13px;margin-top:12px">
            Doanh thu được lọc theo ngày thanh toán.
            Đơn chưa thanh toán và đơn hủy được lọc theo ngày đặt.
            Chỉ cho phép xem dữ liệu đến ngày hiện tại.
        </p>

    </div>

    <!-- Doanh thu theo tháng -->
    <div class="cart-list" style="margin-bottom:25px">

        <h3>Doanh thu theo tháng</h3>

        <?php if (empty($monthlyRevenue)): ?>

            <p>Chưa có dữ liệu doanh thu.</p>

        <?php else: ?>

            <div class="admin-table-wrap">

                <table class="admin-table">

                    <thead>
                        <tr>
                            <th>Tháng</th>
                            <th>Doanh thu</th>
                        </tr>
                    </thead>

                    <tbody>

                        <?php foreach ($monthlyRevenue as $month): ?>

                            <tr>
                                <td><?= e($month["month_name"]) ?></td>

                                <td>
                                    <strong>
                                        <?= money($month["revenue"]) ?>
                                    </strong>
                                </td>
                            </tr>

                        <?php endforeach; ?>

                    </tbody>

                </table>

            </div>

        <?php endif; ?>

    </div>

    <!-- Danh sách đơn hàng -->
    <div class="cart-list">

        <h3>Danh sách đơn hàng đã thanh toán</h3>

        <div style="margin:15px 0">

            <a href="export_excel.php" class="btn">
                Xuất báo cáo
            </a>

        </div>

        <div class="admin-table-wrap">

            <table class="admin-table">

                <thead>
                    <tr>
                        <th>Mã đơn</th>
                        <th>Khách hàng</th>
                        <th>Tổng tiền</th>
                        <th>Phương thức</th>
                        <th>Trạng thái</th>
                        <th>Ngày thanh toán</th>
                    </tr>
                </thead>

                <tbody>

                    <?php if (empty($orders)): ?>

                        <tr>
                            <td colspan="6" style="text-align:center">
                                Chưa có đơn hàng đã thanh toán.
                            </td>
                        </tr>

                    <?php else: ?>

                        <?php foreach ($orders as $order): ?>

                            <tr>

                                <td>#<?= (int)$order["id"] ?></td>

                                <td><?= e($order["receiver"]) ?></td>

                                <td>
                                    <?= money($order["total"]) ?>
                                </td>

                                <td>
                                    <?= e($order["payment_method"]) ?>
                                </td>

                                <td>
                                    <?= e($order["payment_status"]) ?>
                                </td>

                                <td>
                                    <?= e($order["paid_at"]) ?>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                    <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

<?php endif; ?>

<?php include "../includes/footer.php"; ?>
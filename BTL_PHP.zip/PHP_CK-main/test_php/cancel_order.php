<?php

session_start();

require_once "includes/data.php";
require_once "includes/functions.php";

requireLogin();

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: my_orders.php");
    exit;
}

// Kiểm tra mã bảo vệ
$token = $_POST["csrf_token"] ?? "";

if (
    empty($_SESSION["csrf_token"]) ||
    !hash_equals($_SESSION["csrf_token"], $token)
) {
    header(
        "Location: my_orders.php?message="
        . urlencode("Yêu cầu không hợp lệ, vui lòng thử lại.")
    );
    exit;
}

$id = (int)($_POST["id"] ?? 0);

if ($id <= 0) {
    header(
        "Location: my_orders.php?message="
        . urlencode("Mã đơn hàng không hợp lệ.")
    );
    exit;
}

// Chỉ chủ đơn hàng mới được hủy và chỉ khi đang chờ xác nhận
$stmt = $pdo->prepare(
    "UPDATE orders
     SET status = 'Đã hủy'
     WHERE id = ?
       AND user_id = ?
       AND status = 'Chờ xác nhận'"
);

$stmt->execute([
    $id,
    (int)$_SESSION["user"]["id"]
]);

if ($stmt->rowCount() > 0) {
    $message = "Đã hủy đơn hàng #" . $id;
} else {
    $message = "Không thể hủy đơn hàng. Đơn hàng chỉ được hủy khi đang ở trạng thái Chờ xác nhận.";
}

header(
    "Location: my_orders.php?message="
    . urlencode($message)
);

exit;
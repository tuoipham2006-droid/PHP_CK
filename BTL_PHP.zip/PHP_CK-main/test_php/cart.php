<?php

session_start();

require_once "includes/data.php";
require_once "includes/functions.php";

include "includes/header.php";

?>

<div class="page-heading">

    <span class="eyebrow">GIỎ HÀNG CỦA BẠN</span>

    <h1>Những cuốn sách đã chọn</h1>
    
    <?php if (!empty($_GET["message"])): ?>

    <div class="notice">
        <?= e($_GET["message"]) ?>
    </div>

    <?php endif; ?> 

</div>


<?php if (empty($_SESSION["cart"])): ?>

    <div class="empty">

        <p>Giỏ hàng của bạn đang trống.</p>

        <a href="index.php" class="btn">
            Tiếp tục mua sách
        </a>

    </div>

<?php else: ?>

    <div class="cart-layout">

        <div class="cart-list">

            <?php foreach ($_SESSION["cart"] as $id => $qty): ?>

                <?php

                $book = findBook($id);

                if (!$book) {
                    continue;
                }

                ?>

                <div class="cart-item">

                    <img
                        src="<?= e($book["image"]) ?>"
                        alt=""
                    >

                    <div class="cart-book">

                        <strong>
                            <?= e($book["title"]) ?>
                        </strong>

                        <small>
                            <?= e($book["author"]) ?>
                        </small>

                        <span>
                            <?= money($book["price"]) ?>
                        </span>

                        <p>
                            Tồn kho:
                            <strong><?= (int)$book["stock"] ?> cuốn</strong>
                        </p>

                        <?php if ((int)$book["stock"] <= 0): ?>

                            <span class="stock-out">
                                Sách đã hết hàng
                            </span>

                        <?php endif; ?>

                    </div>


                    <!-- CẬP NHẬT SỐ LƯỢNG -->

                    <form
                        method="POST"
                        action="cart_action.php"
                        class="quantity-form"
                    >

                    <input type="hidden" name="action" value="update">

                    <input
                        type="hidden"
                        name="id"
                        value="<?= (int)$id ?>"
                    >

                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= e($_SESSION["csrf_token"]) ?>"
                    >

                    <input
                        type="number"
                        name="quantity"
                        min="1"
                        max="<?= min(99, (int)$book["stock"]) ?>"
                        value="<?= (int)$qty ?>"
                        required
                    >

                    <button type="submit" class="text-button">
                        Cập nhật
                    </button>

                    </form>


                    <!-- XÓA SÁCH -->

                    <form method="POST" action="cart_action.php">

                    <input type="hidden" name="action" value="remove">

                        <input
                            type="hidden"
                            name="id"
                            value="<?= (int)$id ?>"
                        >

                    <input
                            type="hidden"
                            name="csrf_token"
                            value="<?= e($_SESSION["csrf_token"]) ?>"
                    >

                    <button type="submit" class="remove">
                            Xóa
                    </button>

                    </form>

                </div>

            <?php endforeach; ?>

        </div>


        <!-- TỔNG TIỀN -->

        <aside class="summary">

            <h3>Tổng đơn hàng</h3>

            <div class="summary-line">

                <span>Số lượng</span>

                <strong>
                    <?= cartCount() ?> sản phẩm
                </strong>

            </div>

            <div class="summary-line total">

                <span>Tổng tiền</span>

                <strong>
                    <?= money(cartTotal()) ?>
                </strong>

            </div>

            <a href="checkout.php" class="btn full">
                Tiến hành đặt hàng
            </a>

            <a href="index.php" class="continue">
                ← Tiếp tục mua sách
            </a>

        </aside>

    </div>

<?php endif; ?>


<?php include "includes/footer.php"; ?>

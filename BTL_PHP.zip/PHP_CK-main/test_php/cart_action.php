
<?php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once "includes/data.php";
require_once "includes/functions.php";

// Admin không được sử dụng giỏ hàng
if (isAdmin()) {
    header("Location: index.php?message=" . urlencode("Tài khoản quản trị không dùng giỏ hàng."));
    exit;
}

// Chỉ chấp nhận POST
if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: index.php?message=" . urlencode("Yêu cầu không hợp lệ."));
    exit;
}

// Kiểm tra CSRF
$token = $_POST["csrf_token"] ?? "";

if (
    !is_string($token) ||
    empty($_SESSION["csrf_token"]) ||
    !hash_equals($_SESSION["csrf_token"], $token)
) {
    header("Location: cart.php?message=" . urlencode("Yêu cầu không hợp lệ."));
    exit;
}

// Lấy thông tin
$id = (int)($_POST["id"] ?? 0);
$action = $_POST["action"] ?? "";

if ($id <= 0) {
    header("Location: cart.php?message=" . urlencode("Mã sách không hợp lệ."));
    exit;
}

$book = findBook($id);

if (!$book) {
    unset($_SESSION["cart"][$id]);
    saveCart();

    header("Location: cart.php?message=" . urlencode("Sách không tồn tại."));
    exit;
}

$stock = (int)$book["stock"];
$currentQuantity = (int)($_SESSION["cart"][$id] ?? 0);

// ================= THÊM SÁCH =================

if ($action === "add") {

    if ($stock <= 0) {
        $message = "Sách đã hết hàng, không thể thêm vào giỏ.";

    } elseif ($currentQuantity >= $stock) {
        $message = "Số lượng trong giỏ đã đạt mức tồn kho.";

    } elseif ($currentQuantity >= 99) {
        $message = "Mỗi sản phẩm chỉ được mua tối đa 99 cuốn.";

    } else {
        $_SESSION["cart"][$id] = $currentQuantity + 1;
        $message = "Đã thêm sách vào giỏ hàng thành công!";
    }
}

// ================= CẬP NHẬT SỐ LƯỢNG =================

elseif ($action === "update") {

    $quantity = filter_var(
        $_POST["quantity"] ?? null,
        FILTER_VALIDATE_INT
    );

    if ($quantity === false || $quantity === null || $quantity < 1) {
        $message = "Số lượng phải là số nguyên lớn hơn 0.";

    } elseif ($quantity > 99) {
        $message = "Mỗi sản phẩm chỉ được mua tối đa 99 cuốn.";

    } elseif ($quantity > $stock) {
        $message = "Kho chỉ còn " . $stock . " cuốn sách này.";

    } else {
        $_SESSION["cart"][$id] = $quantity;
        $message = "Cập nhật giỏ hàng thành công!";
    }
}

// ================= XÓA SÁCH =================

elseif ($action === "remove") {

    unset($_SESSION["cart"][$id]);

    $message = "Đã xóa sách khỏi giỏ hàng.";
}

else {
    $message = "Chức năng không hợp lệ.";
}

// Lưu giỏ hàng vào MySQL nếu người dùng đã đăng nhập
saveCart();

header("Location: cart.php?message=" . urlencode($message));
exit;

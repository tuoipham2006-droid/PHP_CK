
<?php

session_start();

require_once "includes/data.php";
require_once "includes/functions.php";

/** @var PDO $pdo */

// ======================================
// 1. KIỂM TRA ĐĂNG NHẬP
// ======================================

if (!isset($_SESSION["user"])) {
    header("Location: login.php?message=" . urlencode("Vui lòng đăng nhập để đặt hàng"));
    exit;
}

// Admin không được đặt hàng
if (isAdmin()) {
    header("Location: index.php");
    exit;
}

// Kiểm tra giỏ hàng
if (empty($_SESSION["cart"])) {
    header("Location: cart.php");
    exit;
}

$userId = (int)$_SESSION["user"]["id"];

$error = "";

// ======================================
// 2. TẠO MÃ XÁC THỰC ĐƠN HÀNG
// ======================================

if (empty($_SESSION["checkout_token"])) {
    $_SESSION["checkout_token"] = bin2hex(random_bytes(32));
}

// ======================================
// 3. LẤY THÔNG TIN KHÁCH HÀNG
// ======================================

$stmt = $pdo->prepare("
    SELECT phone, address
    FROM users
    WHERE id = ?
");

$stmt->execute([$userId]);

$saved = $stmt->fetch(PDO::FETCH_ASSOC) ?: [];

$phone = $saved["phone"] ?? "";
$address = $saved["address"] ?? "";

$paymentMethod = "COD";

// ======================================
// 4. KIỂM TRA SẢN PHẨM TRONG GIỎ HÀNG
// ======================================

$items = [];
$total = 0;

foreach ($_SESSION["cart"] as $bookId => $quantity) {

    $book = findBook((int)$bookId);
    $quantity = (int)$quantity;

    if ($book && $quantity > 0) {

        $price = (float)$book["price"];

        $items[] = [
            "book" => $book,
            "quantity" => $quantity,
            "price" => $price
        ];

        $total += $price * $quantity;
    }
}

// Không có sản phẩm hợp lệ
if (empty($items)) {

    $_SESSION["cart"] = [];
    saveCart();

    header("Location: cart.php?message=" . urlencode("Giỏ hàng không có sản phẩm hợp lệ."));
    exit;
}

// ======================================
// 5. XỬ LÝ KHI KHÁCH NHẤN ĐẶT HÀNG
// ======================================

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $phone = trim($_POST["phone"] ?? "");
    $address = trim($_POST["address"] ?? "");
    $paymentMethod = $_POST["payment_method"] ?? "COD";

    // Kiểm tra mã xác thực
    $token = $_POST["checkout_token"] ?? "";

    if (
        empty($_SESSION["checkout_token"]) ||
        !hash_equals($_SESSION["checkout_token"], $token)
    ) {

        $error = "Yêu cầu không hợp lệ hoặc đơn hàng đã được gửi trước đó.";

    }

    // Kiểm tra số điện thoại
    elseif ($phone === "") {

        $error = "Vui lòng nhập số điện thoại.";

    }

    elseif (!preg_match("/^0[0-9]{9}$/", $phone)) {

        $error = "Số điện thoại phải có 10 chữ số và bắt đầu bằng số 0.";

    }

    // Kiểm tra địa chỉ
    elseif ($address === "") {

        $error = "Vui lòng nhập địa chỉ nhận hàng.";

    }

    elseif (mb_strlen($address, "UTF-8") > 255) {

        $error = "Địa chỉ nhận hàng không được vượt quá 255 ký tự.";

    }

    // Kiểm tra phương thức thanh toán
    elseif (!in_array($paymentMethod, ["COD", "Chuyển khoản"], true)) {

        $error = "Phương thức thanh toán không hợp lệ.";

    }

    // Kiểm tra giỏ hàng
    elseif (empty($items) || $total <= 0) {

        $error = "Giỏ hàng không hợp lệ.";

    }

    else {

        try {

            // ======================================
            // 6. BẮT ĐẦU GIAO DỊCH DATABASE
            // ======================================

            $pdo->beginTransaction();
            // ======================================
            // KIỂM TRA TỒN KHO TRƯỚC KHI ĐẶT HÀNG
            // ======================================

            foreach ($items as $item) {

                $bookId = (int)$item["book"]["id"];
                $quantity = (int)$item["quantity"];

            // Khóa dòng dữ liệu để tránh hai khách cùng mua
            // vượt quá số lượng tồn kho
            $checkStock = $pdo->prepare("
                SELECT id, title, stock
                FROM books
                WHERE id = ?
                FOR UPDATE
                ");

            $checkStock->execute([$bookId]);

            $stockInfo = $checkStock->fetch(PDO::FETCH_ASSOC);

            if (!$stockInfo) {
                throw new Exception("Sách không còn tồn tại.");
            }

            if ((int)$stockInfo["stock"] < $quantity) {

                throw new Exception(
                    "Sách " . $stockInfo["title"] .
                    " chỉ còn " . $stockInfo["stock"] .
                    " cuốn trong kho. Vui lòng cập nhật giỏ hàng."
                );
            }
}

            // Tạo đơn hàng mới
            $stmt = $pdo->prepare("
                INSERT INTO orders
                (
                    user_id,
                    receiver,
                    phone,
                    address,
                    total,
                    status,
                    payment_method,
                    payment_status
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ");

            $stmt->execute([

                $userId,

                $_SESSION["user"]["fullname"],

                $phone,

                $address,

                $total,

                "Chờ xác nhận",

                $paymentMethod,

                "Chưa thanh toán"

            ]);

            // Lấy mã đơn hàng vừa tạo
            $orderId = (int)$pdo->lastInsertId();

            // ======================================
            // 7. LƯU CHI TIẾT ĐƠN HÀNG
            // ======================================

            $stmt = $pdo->prepare("
                INSERT INTO order_items
                (
                    order_id,
                    book_id,
                    title,
                    quantity,
                    price
                )
                VALUES (?, ?, ?, ?, ?)
            ");

            foreach ($items as $item) {

                $book = $item["book"];

                $bookId = (int)$book["id"];
                $quantity = (int)$item["quantity"];

                // Lưu chi tiết đơn hàng
                $stmt->execute([

                $orderId,

                $bookId,

                $book["title"],

                $quantity,

                $item["price"]

                ]);

                // TRỪ SỐ LƯỢNG SÁCH TRONG KHO
                $updateStock = $pdo->prepare("
                    UPDATE books
                    SET stock = stock - ?
                    WHERE id = ?
                    AND stock >= ?
                ");

                $updateStock->execute([
                    $quantity,
                    $bookId,
                    $quantity
                ]);

                // Nếu không cập nhật được thì hoàn tác đơn hàng
                if ($updateStock->rowCount() !== 1) {

                    throw new Exception(
                        "Không thể trừ tồn kho. Sách " .
                        $book["title"] .
                        " không còn đủ số lượng."
                    );
                }
            }

            // ======================================
            // 8. CẬP NHẬT THÔNG TIN KHÁCH HÀNG
            // ======================================

            $stmt = $pdo->prepare("
                UPDATE users
                SET phone = ?, address = ?
                WHERE id = ?
            ");

            $stmt->execute([

                $phone,

                $address,

                $userId

            ]);

            // ======================================
            // 9. HOÀN TẤT GIAO DỊCH
            // ======================================

            $pdo->commit();

            // Xóa giỏ hàng sau khi lưu đơn thành công
            $_SESSION["cart"] = [];

            saveCart();

            // Đổi mã xác thực để tránh gửi lại đơn cũ
            $_SESSION["checkout_token"] = bin2hex(random_bytes(32));

            // Lưu thông báo đặt hàng thành công
            $_SESSION["order_message"] = "Đặt hàng thành công! Mã đơn hàng: #" . $orderId;

            // ======================================
            // 10. CHUYỂN TRANG THEO PHƯƠNG THỨC
            // ======================================

            if ($paymentMethod === "Chuyển khoản") {

                header("Location: payment.php?id=" . $orderId);
                exit;

            } else {

                header("Location: my_orders.php");
                exit;

            }

        } catch (Throwable $ex) {

            // Nếu có lỗi thì hoàn tác database
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            $error = "Không thể tạo đơn hàng. Vui lòng kiểm tra database và thử lại.";

            // Ghi lỗi để kiểm tra trong localhost
            error_log("Checkout error: " . $ex->getMessage());

        }

    }

}

// ======================================
// 11. HIỂN THỊ GIAO DIỆN
// ======================================

include "includes/header.php";

?>

<div class="auth-wrap">

    <form method="POST" class="auth-card">

        <span class="eyebrow">
            HOÀN TẤT ĐƠN HÀNG
        </span>

        <h1>Thông tin nhận sách</h1>

        <p class="muted">
            Vui lòng kiểm tra thông tin trước khi đặt hàng.
        </p>

        <?php if ($error !== ""): ?>

            <div class="error">
                <?= e($error) ?>
            </div>

        <?php endif; ?>

        <!-- TỔNG TIỀN -->

        <div class="checkout-total">

            <p>Tổng số sản phẩm: <?= count($items) ?> loại</p>

            <p>Tổng thanh toán:</p>

            <h2>
                <?= money($total) ?>
            </h2>

        </div>

        <!-- MÃ XÁC THỰC -->

        <input
            type="hidden"
            name="checkout_token"
            value="<?= e($_SESSION["checkout_token"]) ?>"
        >

        <!-- SỐ ĐIỆN THOẠI -->

        <label>Số điện thoại</label>

        <input
            type="tel"
            name="phone"
            maxlength="10"
            minlength="10"
            pattern="0[0-9]{9}"
            title="Số điện thoại phải có 10 chữ số và bắt đầu bằng số 0"
            value="<?= e($phone) ?>"
            placeholder="Nhập số điện thoại"
            required
        >

        <!-- ĐỊA CHỈ -->

        <label>Địa chỉ nhận hàng</label>

        <textarea
            name="address"
            rows="4"
            maxlength="255"
            placeholder="Nhập địa chỉ nhận sách"
            required
        ><?= e($address) ?></textarea>

        <!-- PHƯƠNG THỨC THANH TOÁN -->

        <label>Phương thức thanh toán</label>

        <select name="payment_method" required>

            <option value="COD"
                <?= $paymentMethod === "COD" ? "selected" : "" ?>>

                Thanh toán khi nhận hàng (COD)

            </option>

            <option value="Chuyển khoản"
                <?= $paymentMethod === "Chuyển khoản" ? "selected" : "" ?>>

                Chuyển khoản ngân hàng (QR Demo)

            </option>

        </select>

        <p class="muted">
            QR chỉ mang tính chất minh họa,
            không thực hiện giao dịch ngân hàng thật.
        </p>

        <!-- NÚT ĐẶT HÀNG -->

        <button
            type="submit"
            class="btn full"
            onclick="this.disabled=true; this.innerText='Đang xử lý...'; this.form.submit();"
        >

            Xác nhận đặt hàng

        </button>

        <a href="cart.php"
           style="display:block;text-align:center;margin-top:15px">

            Quay lại giỏ hàng

        </a>

    </form>

</div>

<?php include "includes/footer.php"; ?>

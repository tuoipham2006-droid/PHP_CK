<?php /** @var array $book */ ?>
<article class="book-card">

    <a href="detail.php?id=<?= $book["id"] ?>"
       class="book-cover">

        <img src="<?= e($book["image"]) ?>"
             alt="<?= e($book["title"]) ?>">

        <?php if ($book["featured"]): ?>
            <span>Nổi bật</span>
        <?php endif; ?>

    </a>

    <div class="book-info">

        <small><?= e($book["category"]) ?></small>

        <h3>
            <a href="detail.php?id=<?= $book["id"] ?>">
                <?= e($book["title"]) ?>
            </a>
        </h3>

        <p><?= e($book["author"]) ?></p>

        <div class="book-bottom">

            <strong>
                <?= money($book["price"]) ?>
            </strong>
             <?php if (!isAdmin()): ?>
            <form method="POST" action="cart_action.php">

            <input type="hidden" name="action" value="add">

            <input
                type="hidden"
                name="id"
                value="<?= (int)$book["id"] ?>"
            >

            <input
                type="hidden"
                name="csrf_token"
                value="<?= e($_SESSION["csrf_token"]) ?>"
            >

            <button type="submit" class="add-link">
                + Giỏ hàng
            </button>

        </form>
              <?php endif; ?>
        </div>

    </div>

</article>

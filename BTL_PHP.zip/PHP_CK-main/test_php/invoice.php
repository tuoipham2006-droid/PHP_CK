
<?php

// ======================================
// 1. KHỞI ĐỘNG VÀ KẾT NỐI
// ======================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . "/includes/data.php";
require_once __DIR__ . "/includes/functions.php";

// Kiểm tra đăng nhập
requireLogin();

$id = (int)($_GET["id"] ?? 0);
$userId = (int)($_SESSION["user"]["id"] ?? 0);

// Kiểm tra mã đơn hàng
if ($id <= 0) {
    http_response_code(400);
    die("Mã đơn hàng không hợp lệ.");
}

// ======================================
// 2. LẤY THÔNG TIN ĐƠN HÀNG
// ======================================

$order = findOrder($id);

// Kiểm tra đơn hàng và quyền sở hữu
if (!$order || (int)$order["user_id"] !== $userId) {
    http_response_code(404);
    die("Không tìm thấy hóa đơn hoặc bạn không có quyền xem hóa đơn này.");
}

// Chỉ xuất hóa đơn khi đã thanh toán
if (($order["payment_status"] ?? "") !== "Đã thanh toán") {
    die("Đơn hàng chưa được xác nhận thanh toán nên chưa thể xuất hóa đơn.");
}

// Kiểm tra tổng tiền
$total = $order["total"] ?? $order["total_price"] ?? null;

if (!is_numeric($total) || (float)$total < 0) {
    die("Không tìm thấy thông tin tổng tiền đơn hàng.");
}

// Lấy chi tiết đơn hàng
$items = getOrderItems($id);

// ======================================
// 3. HIỂN THỊ HÓA ĐƠN
// ======================================

include __DIR__ . "/includes/header.php";

?>

<div class="cart-list invoice-print-area"
     style="max-width:750px;margin:30px auto;padding:30px">

    <!-- TIÊU ĐỀ -->

    <div style="text-align:center">

        <h1>HIỆU SÁCH NHỎ</h1>

        <p>HÓA ĐƠN BÁN HÀNG</p>

        <h3>Mã hóa đơn: #<?= (int)$id ?></h3>

    </div>

    <hr>

    <!-- THÔNG TIN KHÁCH HÀNG -->

    <h3>Thông tin khách hàng</h3>

    <p>
        <strong>Khách hàng:</strong>
        <?= e($order["fullname"] ?? "") ?>
    </p>

    <p>
        <strong>Số điện thoại:</strong>
        <?= e($order["phone"] ?? "") ?>
    </p>

    <p>
        <strong>Địa chỉ:</strong>
        <?= e($order["address"] ?? "") ?>
    </p>

    <p>
        <strong>Ngày đặt:</strong>
        <?= e($order["created_at"] ?? "") ?>
    </p>

    <p>
        <strong>Phương thức:</strong>
        <?= e($order["payment_method"] ?? "") ?>
    </p>

    <p>
        <strong>Thanh toán:</strong>
        <?= e($order["payment_status"] ?? "") ?>
    </p>

    <?php if (!empty($order["paid_at"])): ?>

        <p>
            <strong>Ngày thanh toán:</strong>
            <?= e($order["paid_at"]) ?>
        </p>

    <?php endif; ?>

    <hr>

    <!-- CHI TIẾT SẢN PHẨM -->

    <h3>Chi tiết sản phẩm</h3>

    <table style="width:100%;border-collapse:collapse">

        <thead>

            <tr style="border-bottom:1px solid #ddd">

                <th align="left" style="padding:10px 5px">
                    Tên sách
                </th>

                <th align="center" style="padding:10px 5px">
                    Số lượng
                </th>

                <th align="right" style="padding:10px 5px">
                    Đơn giá
                </th>

                <th align="right" style="padding:10px 5px">
                    Thành tiền
                </th>

            </tr>

        </thead>

        <tbody>

            <?php if (empty($items)): ?>

                <tr>
                    <td colspan="4" align="center">
                        Không có sản phẩm trong đơn hàng.
                    </td>
                </tr>

            <?php else: ?>

                <?php foreach ($items as $item): ?>

                    <?php
                    $quantity = (int)($item["quantity"] ?? 0);
                    $price = (float)($item["price"] ?? 0);
                    $subtotal = $price * $quantity;
                    ?>

                    <tr style="border-bottom:1px solid #eee">

                        <td style="padding:10px 5px">
                            <?= e($item["title"] ?? "") ?>
                        </td>

                        <td align="center">
                            <?= $quantity ?>
                        </td>

                        <td align="right">
                            <?= money($price) ?>
                        </td>

                        <td align="right">
                            <?= money($subtotal) ?>
                        </td>

                    </tr>

                <?php endforeach; ?>

            <?php endif; ?>

        </tbody>

    </table>

    <hr>

    <!-- TỔNG TIỀN -->

    <h2 style="text-align:right;color:#9b704e">

        Tổng tiền: <?= money($total) ?>

    </h2>

    <!-- NÚT XUẤT HÓA ĐƠN -->

    <div class="no-print"
         style="text-align:center;margin-top:30px">

        <button
            type="button"
            onclick="window.print()"
            class="btn">

            Xuất hóa đơn PDF / In hóa đơn

        </button>

        <a href="my_orders.php" class="btn">

            Quay lại đơn hàng

        </a>

    </div>

    <p style="text-align:center;margin-top:25px">

        Cảm ơn bạn đã mua sách tại Hiệu Sách Nhỏ!

    </p>

</div>

<!-- ĐỊNH DẠNG IN PDF -->

<style>

@media print {

    @page {
        size: A4;
        margin: 15mm;
    }

    body {
        background: #fff !important;
        color: #000 !important;
    }

    header,
    footer,
    .site-header,
    .no-print {
        display: none !important;
    }

    .invoice-print-area {
        width: 100% !important;
        max-width: none !important;
        margin: 0 !important;
        padding: 0 !important;
        box-shadow: none !important;
        border: none !important;
    }

    table {
        page-break-inside: auto;
    }

    tr {
        page-break-inside: avoid;
    }

}

</style>

<?php include __DIR__ . "/includes/footer.php"; ?>

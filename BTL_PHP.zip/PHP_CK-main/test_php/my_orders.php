<?php

// ======================================
// 1. KHỞI ĐỘNG VÀ KẾT NỐI
// ======================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . "/includes/data.php";
require_once __DIR__ . "/includes/functions.php";

requireLogin();

$userId = (int)($_SESSION["user"]["id"] ?? 0);

// ======================================
// 2. TẠO TOKEN BẢO VỆ
// ======================================

if (empty($_SESSION["csrf_token"])) {
    $_SESSION["csrf_token"] = bin2hex(random_bytes(32));
}

// ======================================
// 3. LẤY DANH SÁCH ĐƠN HÀNG
// ======================================

$orders = getOrdersByUser($userId);

include __DIR__ . "/includes/header.php";

?>

<!-- TIÊU ĐỀ -->

<div class="page-heading">

    <span class="eyebrow">
        ĐƠN HÀNG CỦA BẠN
    </span>

    <h1>Lịch sử mua hàng</h1>

    <?php if (!empty($_GET["message"])): ?>

        <div class="notice">

            <?= e($_GET["message"]) ?>

        </div>

    <?php endif; ?>

</div>

<!-- DANH SÁCH ĐƠN HÀNG -->

<?php foreach ($orders as $order): ?>

    <?php

    $orderId = (int)$order["id"];

    $paymentStatus =
        $order["payment_status"] ?? "Chưa thanh toán";

    $paymentMethod =
        $order["payment_method"] ?? "";

    $orderStatus =
        $order["status"] ?? "";

    $isPaid =
        ($paymentStatus === "Đã thanh toán");

    $isCancelled =
        ($orderStatus === "Đã hủy");

    ?>

    <div class="cart-list order-card">

        <h3>
            Đơn hàng #<?= $orderId ?>
        </h3>

        <p>
            Ngày đặt:
            <?= e($order["created_at"] ?? "") ?>
        </p>

        <p>
            Địa chỉ:
            <?= e($order["address"] ?? "") ?>
        </p>

        <p>
            Số điện thoại:
            <?= e($order["phone"] ?? "") ?>
        </p>

        <p>
            Trạng thái:
            <strong>
                <?= e($orderStatus) ?>
            </strong>
        </p>

        <p>
            Thanh toán:
            <strong>
                <?= e($paymentStatus) ?>
            </strong>
        </p>

        <p>
            Phương thức:
            <?= e($paymentMethod) ?>
        </p>

        <p>
            Tổng tiền:
            <strong>
                <?= money($order["total_price"] ?? $order["total"] ?? 0) ?>
            </strong>
        </p>

        <!-- SÁCH ĐÃ MUA -->

        <h4>Sách đã mua</h4>

        <?php foreach (getOrderItems($orderId) as $item): ?>

            <p>

                <?= e($item["title"] ?? "") ?>

                - Số lượng:

                <?= (int)($item["quantity"] ?? 0) ?>

            </p>

        <?php endforeach; ?>

        <!-- CÁC NÚT CHỨC NĂNG -->

        <div class="order-actions"
             style="display:flex;gap:10px;flex-wrap:wrap;margin-top:18px">

            <!-- XUẤT HÓA ĐƠN -->

            <?php if ($isPaid && !$isCancelled): ?>

                <a href="invoice.php?id=<?= $orderId ?>"
                   class="btn">

                    Xem / Xuất hóa đơn

                </a>

            <?php endif; ?>

            <!-- THANH TOÁN -->

            <?php if (
                !$isPaid &&
                !$isCancelled &&
                $paymentMethod === "Chuyển khoản"
            ): ?>

                <a href="payment.php?id=<?= $orderId ?>"
                   class="btn">

                    Thanh toán ngay

                </a>

            <?php endif; ?>

            <!-- HỦY ĐƠN HÀNG -->

            <?php if ($orderStatus === "Chờ xác nhận"): ?>

                <form
                    method="POST"
                    action="cancel_order.php"
                    onsubmit="return confirm('Bạn có chắc chắn muốn hủy đơn hàng này không?');"
                >

                    <input
                        type="hidden"
                        name="id"
                        value="<?= $orderId ?>"
                    >

                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?= e($_SESSION["csrf_token"]) ?>"
                    >

                    <button type="submit" class="remove">

                        Hủy đơn hàng

                    </button>

                </form>

            <?php else: ?>

                <p class="muted" style="margin:0">

                    Đơn hàng này không còn ở trạng thái chờ xác nhận nên không thể hủy.

                </p>

            <?php endif; ?>

            <!-- THÔNG BÁO -->

            <?php if (!$isPaid): ?>

                <p class="muted"
                   style="width:100%;margin:4px 0 0">

                    Hóa đơn chỉ được xuất sau khi đơn hàng được xác nhận đã thanh toán.

                </p>

            <?php endif; ?>

        </div>

    </div>

<?php endforeach; ?>

<!-- KHÔNG CÓ ĐƠN HÀNG -->

<?php if (empty($orders)): ?>

    <div class="empty">

        Bạn chưa có đơn hàng nào.

        <br><br>

        <a href="index.php" class="btn">

            Mua sách ngay

        </a>

    </div>

<?php endif; ?>

<?php include __DIR__ . "/includes/footer.php"; ?>

<?php

// ======================================
// 1. KHỞI ĐỘNG VÀ KẾT NỐI
// ======================================

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

require_once __DIR__ . "/includes/data.php";
require_once __DIR__ . "/includes/functions.php";

// Kiểm tra đăng nhập
requireLogin();

$userId = (int)($_SESSION["user"]["id"] ?? 0);
$orderId = (int)($_GET["id"] ?? 0);

$error = "";

// Kiểm tra mã đơn hàng
if ($orderId <= 0) {
    die("Mã đơn hàng không hợp lệ!");
}

// ======================================
// 2. LẤY THÔNG TIN ĐƠN HÀNG
// ======================================

try {

    $order = findOrder($orderId);

} catch (PDOException $ex) {

    error_log("Payment error: " . $ex->getMessage());

    die("Không thể lấy thông tin đơn hàng. Vui lòng thử lại.");
}

// Kiểm tra đơn hàng tồn tại
if (!$order) {
    die("Không tìm thấy đơn hàng!");
}

// Kiểm tra quyền sở hữu đơn hàng
if ((int)$order["user_id"] !== $userId) {
    die("Bạn không có quyền thanh toán đơn hàng này!");
}

// Kiểm tra phương thức thanh toán
if (($order["payment_method"] ?? "") !== "Chuyển khoản") {
    header("Location: my_orders.php");
    exit;
}

// Kiểm tra đơn hàng đã bị hủy
if (($order["status"] ?? "") === "Đã hủy") {
    die("Đơn hàng đã bị hủy, không thể thanh toán!");
}

// ======================================
// 3. KIỂM TRA TỔNG TIỀN ĐƠN HÀNG
// ======================================

// Không truy cập trực tiếp $order["total"] khi chưa kiểm tra
if (!array_key_exists("total", $order) || !is_numeric($order["total"])) {

    error_log("Payment error: Missing or invalid total for order ID " . $orderId);

    die("Không tìm thấy thông tin tổng tiền đơn hàng. Vui lòng kiểm tra lại dữ liệu đơn hàng!");

}

$total = (float)$order["total"];

// Không cho thanh toán đơn hàng có tổng tiền không hợp lệ
if ($total <= 0) {
    die("Tổng tiền đơn hàng không hợp lệ!");
}

// ======================================
// 4. TẠO MÃ XÁC THỰC
// ======================================

if (empty($_SESSION["payment_token"])) {
    $_SESSION["payment_token"] = bin2hex(random_bytes(32));
}

// ======================================
// 5. XỬ LÝ THANH TOÁN DEMO
// ======================================

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $token = $_POST["payment_token"] ?? "";

    // Kiểm tra mã xác thực
    if (
        empty($_SESSION["payment_token"]) ||
        !is_string($token) ||
        !hash_equals($_SESSION["payment_token"], $token)
    ) {

        $error = "Yêu cầu không hợp lệ. Vui lòng tải lại trang.";

    }

    // Không cho xác nhận lại đơn đã thanh toán
    elseif (($order["payment_status"] ?? "") === "Đã thanh toán") {

        header("Location: invoice.php?id=" . $orderId);
        exit;

    }

    else {

        try {

            // Chỉ cập nhật đơn chưa bị hủy và chưa thanh toán
            $stmt = $pdo->prepare("
                UPDATE orders
                SET
                    payment_status = 'Đã thanh toán',
                    paid_at = NOW()
                WHERE id = ?
                    AND user_id = ?
                    AND status <> 'Đã hủy'
                    AND payment_method = 'Chuyển khoản'
                    AND payment_status <> 'Đã thanh toán'
            ");

            $stmt->execute([$orderId, $userId]);

            // Lấy lại thông tin đơn hàng sau khi cập nhật
            $order = findOrder($orderId);

            // Kiểm tra trạng thái thực tế
            if (
                $order &&
                ($order["status"] ?? "") !== "Đã hủy" &&
                ($order["payment_status"] ?? "") === "Đã thanh toán"
            ) {

                // Đổi mã xác thực để tránh gửi lại yêu cầu cũ
                $_SESSION["payment_token"] = bin2hex(random_bytes(32));

                // Chuyển sang hóa đơn
                header("Location: invoice.php?id=" . $orderId);
                exit;

            } else {

                $error = "Không thể xác nhận thanh toán. Đơn hàng có thể đã bị hủy hoặc đã thay đổi trạng thái.";

            }

        } catch (PDOException $ex) {

            error_log("Payment update error: " . $ex->getMessage());

            $error = "Có lỗi xảy ra khi thanh toán. Vui lòng thử lại.";

        }

    }

}

// ======================================
// 6. HIỂN THỊ GIAO DIỆN
// ======================================

include __DIR__ . "/includes/header.php";

?>

<!-- TIÊU ĐỀ -->

<div class="page-heading">

    <span class="eyebrow">
        THANH TOÁN ĐƠN HÀNG
    </span>

    <h1>Thanh toán bằng mã QR</h1>

    <p>
        Hoàn tất đơn hàng tại Hiệu Sách Nhỏ
    </p>

</div>

<!-- KHUNG THANH TOÁN -->

<div class="cart-list"
     style="max-width:600px;margin:30px auto;padding:30px;text-align:center">

    <h2>Hiệu Sách Nhỏ</h2>

    <p>
        Mã đơn hàng:
        <strong>#<?= (int)$orderId ?></strong>
    </p>

    <p>Số tiền cần thanh toán:</p>

    <h1 style="color:#9b704e;font-size:30px">

        <?= money($total) ?>

    </h1>

    <!-- MÃ QR TƯỢNG TRƯNG -->

    <div style="
        width:220px;
        height:220px;
        margin:25px auto;
        padding:10px;
        border:1px solid #ddd;
        background:white;
        display:flex;
        align-items:center;
        justify-content:center;
    ">

        <div style="
            width:190px;
            height:190px;
            background-image:
            repeating-conic-gradient(
                #222 0% 25%,
                white 0% 50%
            );
            background-size:20px 20px;
            display:flex;
            align-items:center;
            justify-content:center;
        ">

            <span style="
                background:white;
                padding:12px;
                font-weight:bold;
                color:#49392b;
                font-size:18px;
            ">
                DEMO QR
            </span>

        </div>

    </div>

    <!-- THÔNG TIN THANH TOÁN -->

    <div style="text-align:left;max-width:350px;margin:20px auto">

        <p>
            <strong>Ngân hàng:</strong> Minh họa
        </p>

        <p>
            <strong>Số tiền:</strong>
            <?= money($total) ?>
        </p>

        <p>
            <strong>Nội dung:</strong>
            HIEUSACH <?= (int)$orderId ?>
        </p>

        <p>
            <strong>Phương thức:</strong>
            Chuyển khoản Demo
        </p>

    </div>

    <p style="color:#b06d38">
        Đây là mã QR tượng trưng, không thực hiện giao dịch ngân hàng thật.
    </p>

    <hr style="margin:25px 0">

    <!-- THÔNG BÁO LỖI -->

    <?php if ($error !== ""): ?>

        <div class="error">
            <?= e($error) ?>
        </div>

    <?php endif; ?>

    <!-- KIỂM TRA TRẠNG THÁI THANH TOÁN -->

    <?php if (($order["payment_status"] ?? "") === "Đã thanh toán"): ?>

        <h3 style="color:green">
            Thanh toán Demo thành công!
        </h3>

        <a href="invoice.php?id=<?= (int)$orderId ?>"
           class="btn">

            Xem hóa đơn

        </a>

    <?php else: ?>

        <form method="POST"
              action="payment.php?id=<?= (int)$orderId ?>"
              onsubmit="return confirm('Bạn xác nhận thanh toán Demo đơn hàng này?')">

            <input
                type="hidden"
                name="payment_token"
                value="<?= e($_SESSION["payment_token"]) ?>"
            >

            <button type="submit" class="btn">

                Tôi đã thanh toán (Demo)

            </button>

        </form>

    <?php endif; ?>

    <br><br>

    <a href="my_orders.php">
        Quay lại đơn hàng của tôi
    </a>

</div>

<?php include __DIR__ . "/includes/footer.php"; ?>
